export const HUB_IP = "192.168.4.1";
export const BASE_URL = `http://${HUB_IP}`;
